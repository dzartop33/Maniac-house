// Копирует index.html и иконки в android-build/www/ для упаковки в APK
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DST_DIR = path.join(__dirname, 'www');

if (!fs.existsSync(DST_DIR)) fs.mkdirSync(DST_DIR, { recursive: true });

// Копируем index.html с правкой: по умолчанию мобильная платформа
let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const inject = `
<script>
  // Android-сборка: по умолчанию mobile
  if (!localStorage.getItem('mh_platform')) {
    localStorage.setItem('mh_platform', 'mobile');
  }
  // В APK прячем LAN-онлайн (нужен ПК-сервер)
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#menuOnlineHub button').forEach(b => {
      if (b.textContent && b.textContent.includes('ЛОКАЛЬНАЯ')) b.style.display = 'none';
    });
  });
</script>`;
html = html.replace('<title>', inject + '\n<title>');
fs.writeFileSync(path.join(DST_DIR, 'index.html'), html);
console.log('✓ index.html скопирован (' + (html.length/1024).toFixed(1) + ' KB)');

// Иконки
for (const f of ['icon-192.png', 'icon-512.png']) {
  const src = path.join(ROOT, f);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(DST_DIR, f));
    console.log('✓ ' + f);
  }
}

// Минимальный manifest
const manifest = {
  name: 'Дом Палача', short_name: 'Дом Палача',
  start_url: './index.html', display: 'fullscreen',
  background_color: '#0a0807', theme_color: '#5a0a0a',
  icons: [
    { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
    { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
  ],
};
fs.writeFileSync(path.join(DST_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2));
console.log('✓ manifest.json');
